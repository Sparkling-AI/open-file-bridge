// Open File Bridge — FS adapter router (Stage 3).
//
// sw.js routes pipe messages here. Response shapes mirror the desktop app
// (v2.11) endpoint-for-endpoint so every skill recipe keeps working.
// Engines (/pdf_text /ocr /ocr_pdf /pdf_op) forward to the engine page
// via ENGINE_RPC (fs-engine.js, P3/P4); until those phases land the
// router answers with an honest 501 "engine not yet bundled".

"use strict";

/* ---------------- engine wheels (bundled, served via the pipe) -------- */

// Served from extension/vendor/wheels/ at runtime via
// chrome.runtime.getURL (no build-time injection — keeps first-party JS
// as-authored and reviewable; the pipe contract is unchanged).
const FS_WHEELS = [
  "defusedxml-0.7.1-py2.py3-none-any.whl",
  "et_xmlfile-2.0.0-py3-none-any.whl",
  "fonttools-4.63.0-py3-none-any.whl",
  "fpdf2-2.8.8-py3-none-any.whl",
  "olefile-0.47-py2.py3-none-any.whl",
  "openpyxl-3.1.5-py2.py3-none-any.whl",
  "python_docx-1.2.0-py3-none-any.whl",
  "python_pptx-1.0.2-py3-none-any.whl",
  "typing_extensions-4.16.0-py3-none-any.whl",
];

/* ---------------- the router ---------------- */

async function fsRoute(method, pathWithQs, bodyText, b64Mode) {
  const qi = pathWithQs.indexOf("?");
  const path = qi < 0 ? pathWithQs : pathWithQs.slice(0, qi);
  const q = parseQueryString(pathWithQs);
  let body = {};
  if (bodyText) {
    try { body = JSON.parse(bodyText); }
    catch (e) { return fsFail(400, { error: "invalid JSON body" }); }
  }

  /* ---- meta endpoints (the app served these token-free; in the
     extension the SW sender gate covers ALL endpoints uniformly — a
     blocked sender gets a self-explaining 403 instead, which the skill
     turns into "add this site in the extension settings") ------------- */

  if (method === "GET" && path === "/health") {
    const roots = await enabledRoots();
    const ros = [];
    for (const r of roots) {
      const ps = await permState(r.handle, r.mode === "read" ? "read" : "readwrite");
      ros.push({ id: r.id, path: r.alias || r.id, alias: r.alias || null, perm: ps });
    }
    const info = ros.length
      ? { ok: true, roots: ros, version: FS_VERSION }
      : { ok: false, hint: "no folder chosen yet", roots: [], version: FS_VERSION };
    if (ros.length) info.root = ros[0].path;
    info.addons = { pdf: FS_ENGINES.pdf, ocr: FS_ENGINES.ocr };
    info.engine_alive = FS_ENGINE_ALIVE; // engine host heartbeat (fs-engine)
    // undocumented-field guard (2026-09-09): a model reading /health saw
    // engine_alive:false and told the user OCR was unavailable WITHOUT
    // calling the endpoint — make the field self-explanatory
    info.engine_alive_hint = "false is NORMAL before the first engine call — engines auto-start (invisibly) when /pdf_text /ocr /ocr_pdf /pdf_op is called";
    info.ocr_lang = await kvGet("ocr_lang", "eng");
    info.ocr_langs_available = FS_ENGINES.ocr ? FS_OCR_LANGS : [];
    info.wheels = FS_WHEELS.length;
    info.security = await secMode();
    info.locked = info.security === "UNLOCKED";
    // pilot 3.4.0: short actionable hints — models acted on /health without
    // reading the skill (root /list on network shares flooded contexts)
    info.hints = ros.length ? [
      "list with a path (never the bare root of a big or network share): /list?path=<folder>&depth=1",
      (ros.length > 1
        ? "several folders shared — prefix every path with a root id (" +
          ros.map((r) => r.id).join(", ") + "): " + ros[0].id + "/sub/file.ext"
        : "paths are relative to the shared folder; no leading / needed"),
      "keep each request under ~45 s — the host kills code cells at 60 s",
    ] : ["no folder chosen yet — the user must click the Open File Bridge toolbar icon and pick one"];
    return fsOk(info);
  }

  if (method === "GET" && path === "/version") {
    return fsOk({ bridge: FS_VERSION, skill_min: FS_SKILL_MIN,
      note: "skills older than skill_min may miss endpoints; update the skill via scripts/setup_owui.py" });
  }

  if (method === "GET" && path === "/state") {
    const roots = await enabledRoots();
    const ros = roots.map((r) => ({
      id: r.id, path: r.alias || r.id, alias: r.alias || null, mode: r.mode || "readwrite",
      readonly: r.mode === "read" || !!r.readonly,
      writes_enabled: r.writesEnabled !== false,
    }));
    const lim = await rateLimits();
    const secSite = await secAllowedSite();
    return fsOk({
      root: ros.length ? ros[0].path : null,
      roots: ros, port: null,
      ocr_lang: await kvGet("ocr_lang", "eng"),
      allowed_origin: secSite,
      security: await secMode(),
      token_required: (await secBridgeToken()) !== null,
      readonly: await kvGet("readonly_global", false), readonly_source: "setting",
      allow_reveal: false,
      ignore_global: await kvGet("ignore_global", []),
      rate_limits: { max_writes: lim.w, max_mb: Math.floor(lim.b / 1024 / 1024),
        writes_source: "setting", mb_source: "setting" },
      engine_auto_open: await kvGet("engine_auto_open", true),
      confirm_scope: await kvGet("confirm_scope", "all"),
    });
  }

  if (method === "GET" && path === "/wheels") {
    return fsOk({ wheels: FS_WHEELS });
  }
  if (method === "GET" && path.startsWith("/wheels/")) {
    const name = unquoteComp(path.slice(8));
    if (!FS_WHEELS.includes(name)) {
      return fsFail(404, { error: "no such wheel: " + name });
    }
    if (typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.getURL) {
      return fsFail(500, { error: "wheels need the extension runtime" });
    }
    try {
      const res = await fetch(chrome.runtime.getURL("vendor/wheels/" + name));
      if (!res.ok) return fsFail(404, { error: "wheel not packaged: " + name });
      const buf = new Uint8Array(await res.arrayBuffer());
      if (buf.length > MAX_BINARY) {
        return fsFail(413, { error: "wheel too large: " + buf.length });
      }
      return { status: 200, bodyB64: b64enc(buf) };
    } catch (e) {
      return fsFail(500, { error: "wheel read failed: " + e });
    }
  }

  if (method === "GET" && path === "/ocr/config") {
    return fsOk({ ocr_lang: await kvGet("ocr_lang", "eng"), available: FS_ENGINES.ocr ? FS_OCR_LANGS : [] });
  }

  if (method === "POST" && path === "/ocr/lang") {
    const raw = String(body.lang || "");
    const parts = raw.split(/[\s,+]+/).filter(Boolean).filter((p) => /^[a-zA-Z_]{2,8}$/.test(p));
    if (!parts.length) return fsFail(400, { error: "bad lang: " + raw });
    await kvSet("ocr_lang", parts.join("+"));
    return fsOk({ ok: true, ocr_lang: parts.join("+"), available: FS_OCR_LANGS });
  }

  if (path.startsWith("/click/")) {
    return fsFail(404, { error: "outcome links were removed in extension 3.3.0 — show the file's path in your answer instead" });
  }

  if (method === "GET" && path === "/guide") {
    return fsOk({ guide_url: "guide.html", note: "the recovery guide is rendered by the extension page" });
  }

  /* ---- reads ---- */

  try {
    if (method === "GET" && path === "/list") {
      const rel = formUnquote(q.path || ".");
      const roots = await enabledRoots();
      if (!roots.length) throw new OpFail(503, { error: "no shared folder configured — click the Open File Bridge toolbar icon and choose a folder" });
      let rootRec = roots[0];
      let startParts = [];
      let ambiguous = false;
      if (rel && rel !== "." && rel !== "/") {
        const seg0 = rel.split("/")[0];
        if (seg0 && ROOT_ID_RE.test(seg0) && roots.some((r) => r.id === seg0)) {
          rootRec = roots.find((r) => r.id === seg0);
          const rest = rel.slice(seg0.length).replace(/^\/+/, "");
          startParts = rest.split("/").filter(Boolean);
        } else if (roots.length > 1) {
          const aliasHit = roots.find((r) => {
            const a = String(r.alias || "").toLowerCase();
            const p = String(r.path || "").toLowerCase();
            return a && a === seg0.toLowerCase() || p && p === seg0.toLowerCase();
          });
          if (aliasHit) {
            rootRec = aliasHit;
            const rest = rel.slice(seg0.length).replace(/^\/+/, "");
            startParts = rest.split("/").filter(Boolean);
          } else {
            startParts = rel.split("/").filter(Boolean);
            ambiguous = true;
          }
        } else {
          startParts = rel.split("/").filter(Boolean);
        }
      }
      // per-op permission re-check (plan §4.3) — same structured shape as
      // resolveGuarded; /list does not go through resolveGuarded
      const ps = await permState(rootRec.handle, "read");
      if (ps !== "granted") {
        throw new OpFail(403, {
          error: "permission needed: the browser requires the user to re-confirm access to '" +
            (rootRec.alias || rootRec.id) + "'",
          permission_needed: true,
          root_id: rootRec.id,
          mode: "read",
          hint: "tell the user: click the Open File Bridge toolbar icon and press Reconnect — the folder is NOT re-picked, permission is re-asked on the stored handle",
        });
      }
      // pilot 3.4.0: a BARE root listing is depth-1 + hints (a recursive
      // root /list on a network share flooded model contexts / timed out,
      // 25× in the pilot); an explicit path keeps the recursive default
      // (existing callers rely on it), and depth/max_entries/fields work
      // everywhere. depth=0 means "as deep as before" (unbounded).
      const atRoot = !startParts.length;
      const depthReq = q.depth !== undefined
        ? parseInt(q.depth, 10)
        : (atRoot ? 1 : 0);
      const maxEntries = q.max_entries !== undefined
        ? Math.max(1, Math.min(parseInt(q.max_entries, 10) || MAX_LIST, 2000))
        : MAX_LIST;
      const fieldsParam = String(q.fields || "").split(",").map((s) => s.trim())
        .filter(Boolean);
      const wantFields = fieldsParam.length
        ? new Set(fieldsParam.map((f) => f.toLowerCase()))
        : null;
      // pilot item 17 (2026-10-23): name= substring filter, case- and
      // accent-insensitive — a capped 500-entry /list once hid a file
      // and the model reported it nonexistent (case D03).
      // unquoteComp: parseQueryString is deliberately raw (paths decode
      // per-endpoint); an encoded name=%C3%A4renden must decode first
      const nameFilter = unquoteComp(String(q.name || "")).trim();
      const namePat = nameFilter ? foldName(nameFilter) : null;
      const depth = Number.isFinite(depthReq) && depthReq > 0 ? depthReq : 0;
      return await listEndpoint(rootRec, startParts, { depth, maxEntries, wantFields, namePat, ambiguous });
    }

    if (method === "GET" && path === "/read") return await epRead(q);
    if (method === "GET" && path === "/peek") return await epPeek(q);
    if (method === "GET" && path === "/read_b64") return await epReadB64(q);
    if (method === "GET" && path === "/stat") return await epStat(q);
    if (method === "GET" && path === "/search") return await epSearch(q);
    if (method === "GET" && path === "/directory_tree") return await epTree(q);
    if (method === "GET" && path === "/image_info") return await epImageInfo(q);
    if (method === "GET" && path === "/image_b64") return await epImageB64(q);
    if (method === "GET" && path === "/find") return await epFind(q);
  } catch (e) { return opFailToResp(e); }

  /* ---- writes, engines, moved ---- */

  try {
    if (method === "POST" && path === "/write") return await epWrite(body, false);
    if (method === "POST" && path === "/write_b64") return await epWrite(body, true);
    if (method === "POST" && path === "/write_b64_chunk") return await epWriteB64Chunk(body);
    if (method === "POST" && path === "/write_many") return await epWriteMany(body);
    if (method === "POST" && path === "/edit") return await epEdit(body);
    if (method === "POST" && path === "/delete") return await epDelete(body);
    if (method === "POST" && path === "/move") return await epMove(body);
    if (method === "POST" && path === "/mkdir") return await epMkdir(body);
    if (method === "POST" && path === "/versions/list") return await epVersionsList(body);
    if (method === "POST" && path === "/versions/read") return await epVersionsRead(body);
    if (method === "POST" && path === "/versions/restore") return await epRestore("versions", body);
    if (method === "POST" && path === "/trash/list") return await epTrashList(body);
    if (method === "POST" && path === "/trash/restore") return await epRestore("trash", body);
    if (method === "POST" && path === "/zip") return await epZip(body);
    if (method === "POST" && path === "/unzip") return await epUnzip(body);
    if (method === "POST" && path === "/link") {
    // outcome links REMOVED in 3.3.0 (Dandan's call): a browser
    // extension cannot open files or the OS file manager, and the
    // link-page experience wasn't worth it — honest 501, keep the
    // route so strays get an explanation instead of "unknown endpoint"
    return fsFail(501, {
      error: "outcome links are gone in extension mode (removed in 3.3.0)",
      hint: "a browser extension cannot open files or the OS file manager — after a write, show the file's path (the response's written field, without the leading /) as a code span in your answer" });
  }
    if (method === "GET" && path === "/reveal") return fsFail(403, {
      error: "reveal is disabled — an extension cannot open the OS file manager",
      hint: "the extension page shows the file path with a copy button" });
    if (path === "/pdf_text" || path === "/ocr" || path === "/ocr_pdf" || path === "/pdf_op") {
      // URL-decode lang at the routing boundary: parseQueryString is
      // deliberately raw (paths decode per-endpoint via unquoteComp), and
      // a properly-encoded swe%2Beng reached the engine un-decoded →
      // sanitizeLangs rejected it → silent English fallback → garbage OCR
      // of a Swedish sign (real chat 2026-09-09)
      if (q.lang !== undefined) q.lang = unquoteComp(q.lang);
      if (body && typeof body.lang === "string") body.lang = unquoteComp(body.lang);
      return await fsEngineRoute(method, path, q, body);
    }
  } catch (e) { return opFailToResp(e); }

  /* ---- moved / dropped ---- */

  if (MOVED_READ_ENDPOINTS.has(path) && method === "GET") {
    return await epMovedRead(path, q);
  }
  if (MOVED_WRITE_ENDPOINTS.has(path) && method === "POST") {
    return fsFail(501, {
      error: path + " is not available in extension mode — use the Pyodide recipe (SKILL-EXT §moved)",
      hint: "read via /read_b64, write via /write_b64, with the bundled wheels" });
  }
  if (path === "/convert") {
    return fsFail(501, {
      error: "/convert is not available in extension mode",
      hint: "two pairs have Pyodide recipes (xlsx→csv, docx→html — SKILL-EXT §Office files); " +
        "everything else: open the file in your office app (Word / Excel / LibreOffice) " +
        "and save as .docx / .xlsx, then I can read and edit it" });
  }

  /* ---- router fall-through: method-aware 405 ----
   * A wrong-method call on a KNOWN endpoint used to 404 "unknown
   * endpoint" — indistinguishable from a typo'd path, and real chats
   * kept endpoint-guessing after it (POST /image_info, GET /link,
   * 2026-09-09). Engine endpoints keep their richer hint in
   * fsEngineRoute; this table covers the rest. */
  const ROUTE_GET = new Set(["/health", "/version", "/state", "/wheels",
    "/ocr/config", "/guide", "/list", "/read", "/peek", "/read_b64",
    "/stat", "/search", "/directory_tree", "/image_info", "/image_b64",
    "/find",
    "/pdf_text", "/ocr"].concat([...MOVED_READ_ENDPOINTS]));
  const ROUTE_POST = new Set(["/ocr/lang", "/write", "/write_b64",
    "/write_b64_chunk", "/write_many", "/edit", "/delete", "/move",
    "/mkdir",
    "/versions/list", "/versions/read", "/versions/restore",
    "/trash/list", "/trash/restore",
    "/zip", "/unzip", "/link", "/ocr_pdf", "/pdf_op"]
    .concat([...MOVED_WRITE_ENDPOINTS]));
  if (ROUTE_GET.has(path)) {
    return fsFail(405, { error: path + " is GET-only — got " + method,
      hint: "call it as GET with query params, e.g. " + path + "?path=<file>" });
  }
  if (ROUTE_POST.has(path)) {
    return fsFail(405, { error: path + " is POST-only — got " + method,
      hint: "POST a JSON body, e.g. {\"path\": \"<file>\"}" });
  }

  return fsFail(404, { error: "unknown endpoint" });
}

function opFailToResp(e) {
  if (e instanceof OpFail) return fsFail(e.status, e.obj);
  return fsFail(500, { error: String((e && e.message) || e) });
}

// csv_head/csv_stats are GET in the app — moved on the GET side since
// 3.2.0 (a GET used to 405 "POST-only" first, misdirecting the model)
const MOVED_READ_ENDPOINTS = new Set(["/eml_read", "/html_text", "/docx_read",
  "/pptx_read", "/xlsx_read", "/csv_head", "/csv_stats"]);
const MOVED_WRITE_ENDPOINTS = new Set(["/docx_write", "/docx_merge", "/docx_mailmerge",
  "/pptx_from_template", "/xlsx_append", "/pdf_from_text"]);

/** Moved read endpoints (plan §2): the FILE is still validated with the
 *  app's semantics (permission gate, sensitive floor, 404/503) so models
 *  get the same errors they know — then a clean 501 + the recipe instead
 *  of parsing anything. */
const MOVED_RECIPES = {
  "/docx_read": 'python-docx from /wheels/python_docx (read via /read_b64, docx.Document(BytesIO(b64decode(...))))',
  "/pptx_read": 'python-pptx from /wheels/python_pptx (read via /read_b64, pptx.Package.open)',
  "/xlsx_read": 'openpyxl from /wheels/openpyxl (read via /read_b64, load_workbook(BytesIO(...)))',
  "/eml_read": "stdlib email module: /read_b64 → email.message_from_bytes",
  "/html_text": "stdlib html.parser or bs4-style regex strip: /read_b64 → decode → strip tags",
  "/csv_head": "plain text — /read it (start_line/max_lines window); stdlib csv module if quoting matters",
  "/csv_stats": "plain text — /read it and count in Python; stdlib csv module if quoting matters",
};

async function epMovedRead(path, q) {
  // validate the target first — same resolution semantics as the app
  // (a missing file / locked permission still gives the app's 404/403,
  // not a generic adapter error)
  let file = null;
  try {
    const rg = await resolveGuarded(formUnquote(q.path || ""));
    file = await getFileFor(rg.rootRec, rg.parts);
  } catch (e) {
    if (e instanceof OpFail) return fsFail(e.status, e.obj);
    return fsFail(400, { error: path + ": bad request — " + e });
  }
  return fsFail(501, {
    moved: true,
    error: path + " is not available in extension mode — the office stack runs in the Pyodide sandbox",
    size: file.size,
    hint: "fetch the bytes with /read_b64?path=" + encodeURIComponent(q.path || "") +
      " then parse in Pyodide: " + (MOVED_RECIPES[path] || "see SKILL-EXT §moved"),
  });
}

/* ---------------- meta helpers ---------------- */

async function listEndpoint(rootRec, startParts, opts) {
  const o = opts || {};
  const depth = o.depth || 0;            // 0 = unbounded (pre-3.4 behavior)
  const maxEntries = o.maxEntries || MAX_LIST;
  const wantFields = o.wantFields || null;
  const namePat = o.namePat || null;     // folded /list?name= filter (3.5.0)
  const pats = await allIgnorePatterns(rootRec);
  const entries = [];
  let truncated = false;
  let startDir = rootRec.handle;
  for (const seg of startParts) {
    try { startDir = await startDir.getDirectoryHandle(seg); }
    catch (e) { return fsFail(404, { error: "not a directory: " + startParts.join("/") }); }
  }
  const t0 = Date.now();
  async function rec(dir, prefixParts, d) {
    for await (const [name, h] of dir.entries()) {
      if (entries.length >= maxEntries) { truncated = true; return; }
      const relParts = prefixParts.concat(name);
      const rel = relParts.join("/");
      const isDir = h.kind === "directory";
      if (ignoreMatch(rel, isDir, pats)) continue;
      if (namePat && !nameMatches(foldName(name), namePat)) continue;
      if (isDir) {
        entries.push(mkEntry(rel, "dir", null, null));
        if (!depth || d < depth) {
          await rec(h, relParts, d + 1);
          if (entries.length >= maxEntries) { truncated = true; return; }
        }
      } else {
        let size = null, mtime = null;
        if (!wantFields || wantFields.has("size") || wantFields.has("mtime")) {
          try {
            const f = await h.getFile();
            if (!wantFields || wantFields.has("size")) size = f.size;
            if (!wantFields || wantFields.has("mtime")) mtime = Math.floor(f.lastModified / 1000);
          } catch (e) {}
        }
        entries.push(mkEntry(rel, "file", size, mtime));
      }
      if (Date.now() - t0 > 10000) { truncated = true; return; }
    }
  }
  function mkEntry(rel, type, size, mtime) {
    const e = { path: rel, type: type };
    if (type === "dir") return e;                       // dirs never had size/mtime
    if (!wantFields) { e.size = size; e.mtime = mtime; return e; }
    if (wantFields.has("size")) e.size = size;
    if (wantFields.has("mtime")) e.mtime = mtime;
    return e;
  }
  await rec(startDir, startParts, 1);
  await auditRow({ endpoint: "/list", method: "GET", path: startParts.join("/") || ".", status: 200, size: entries.length });
  const out = { root: rootRec.alias || rootRec.id, root_id: rootRec.id, entries: entries, truncated: truncated };
  if (depth === 1 && !startParts.length) {
    out.depth = 1;
    out.hint = "top level only — call /list?path=<folder> to go deeper, or depth=N for N levels (a recursive root listing can flood the context on big shares)";
  } else if (depth > 1) {
    out.depth = depth;
  }
  if (truncated && !out.hint) out.hint = "partial listing — folder exceeded the entry/time cap; narrow with path= or max_entries=";
  if (o.ambiguous) {
    out.root_note = "several folders are shared and this path had NO root id — it resolved to '" +
      (rootRec.alias || rootRec.id) + "' (" + rootRec.id + "). Prefix paths with a root id (" +
      (await enabledRoots()).map((r) => r.id).join(", ") + ") to target another folder.";
  }
  return fsOk(out);
}

/* ---------------- read endpoints ---------------- */

async function epRead(q) {
  const rg = await resolveGuarded(formUnquote(q.path || ""));
  const file = await getFileFor(rg.rootRec, rg.parts);
  const name = rg.parts[rg.parts.length - 1];
  const ext = extOf(name);
  const base = name.toLowerCase();
  if (!TEXT_EXTS.has(ext) && !KNOWN_BASENAMES.has(base) && base !== ".gitignore") {
    return fsFail(413, {
      error: "/read is text-only; '" + ext.replace(/^\./, "") + "' is not on the text whitelist (fail-closed)",
      hint: "call /peek?path=…&bytes=512 to identify the file, or /read_b64 for raw bytes" });
  }
  const head = new Uint8Array(await file.slice(0, 16).arrayBuffer());
  const kind = sniffKind(head);
  if (kind) {
    return fsFail(413, { error: "/read is text-only; this file sniffs as " + kind, hint: routingHint(kind, ext) });
  }
  const text = await file.text();
  await auditRow({ endpoint: "/read", method: "GET", path: rg.relInRoot, status: 200, size: file.size });
  const echo = await echoPath(rg);
  // pilot item 11: models parsed the "     N\t" prefixes as file content
  // (JSONDecodeError on JSON, broken CSV). raw=1 returns the plain text;
  // the numbered view stays the default for looking, not parsing.
  if (String(q.raw || "") === "1" || String(q.raw || "").toLowerCase() === "true") {
    let raw = text;
    let truncated = false;
    // 3.5.0 (pilot item 18): raw pages are 2 MB, not 200 k — a 9 MB log
    // needed ~50 small pages and tripped the rate breaker twice (C06)
    if (raw.length > MAX_READ_RAW) { raw = raw.slice(0, MAX_READ_RAW); truncated = true; }
    const out = { path: echo, raw: true, content: raw,
      total_lines: raw === text ? text.split("\n").length : undefined };
    if (truncated) {
      out.truncated = true;
      out.hint = "raw page cut at " + MAX_READ_RAW + " chars — continue with /read?start=<line> or /read_b64 ranges";
    }
    return fsOk(out);
  }
  return fsOk(windowedRead(text, q, echo));
}

function windowedRead(text, q, relPath) {
  const start = Math.max(parseInt(q.start_line || "1", 10) || 1, 1);
  let n = parseInt(q.max_lines || String(DEFAULT_MAX_LINES), 10) || DEFAULT_MAX_LINES;
  n = Math.min(n, DEFAULT_MAX_LINES);
  const selected = [];
  let total = 0, budget = MAX_READ;
  const lines = text.split("\n");
  if (lines.length && lines[lines.length - 1] === "") lines.pop();
  for (let i = 0; i < lines.length; i++) {
    total = i + 1;
    if (i + 1 < start || selected.length >= n) continue;
    let t = lines[i].replace(/\n$/, "");
    if (t.length > MAX_LINE_CHARS) t = t.slice(0, MAX_LINE_CHARS) + "… (line truncated)";
    if (budget - (t.length + 8) < 0) {
      selected.push(String(i + 1).padStart(6) + "\t…(char budget reached — narrow the window)");
      budget = -1;
      break;
    }
    budget -= t.length + 8;
    selected.push(String(i + 1).padStart(6) + "\t" + t);
  }
  const end = selected.length ? start + selected.length - 1 : start - 1;
  const out = {
    path: relPath, start_line: start, end_line: end,
    total_lines: total, content: selected.join("\n"),
  };
  if (end < total) out.note = "showing lines " + start + "-" + end + " of " + total +
    "; call again with start_line=" + (end + 1) + " to continue";
  return out;
}

async function epPeek(q) {
  const rg = await resolveGuarded(formUnquote(q.path || ""));
  const file = await getFileFor(rg.rootRec, rg.parts);
  const n = Math.max(16, Math.min(parseInt(q.bytes || "512", 10) || 512, 4096));
  const head = new Uint8Array(await file.slice(0, n).arrayBuffer());
  const kind = sniffKind(head);
  const name = rg.parts[rg.parts.length - 1];
  const ext = extOf(name);
  const guessed = kind || ((TEXT_EXTS.has(ext) || KNOWN_BASENAMES.has(name.toLowerCase())) ? "text" : "unknown");
  let preview = new TextDecoder("utf-8", { fatal: false }).decode(head);
  preview = Array.from(preview).map((ch) => {
    const code = ch.codePointAt(0);
    if ((code >= 32 && code < 127) || code === 9 || code === 10 || code === 13) return ch;
    return "·";
  }).join("");
  let pr = 0;
  for (const b of head) if ((b >= 32 && b < 127) || b === 9 || b === 10 || b === 13) pr++;
  await auditRow({ endpoint: "/peek", method: "GET", path: rg.relInRoot, status: 200, size: n });
  return fsOk({
    path: q.path, size: file.size, ext: ext || null, kind: guessed,
    printable_ratio: pr / Math.max(head.length, 1),
    preview: preview,
    hint: kind ? routingHint(kind, ext)
      : (guessed === "text" ? "looks like text — /read it"
        : "unknown format — /read_b64 if you need the bytes"),
  });
}

async function epReadB64(q) {
  const rg = await resolveGuarded(formUnquote(q.path || ""));
  const file = await getFileFor(rg.rootRec, rg.parts);
  // pilot item 6: range reads. offset/length let the client pull big
  // files (over the 8 MB whole-file cap) in chunks, mirroring the write
  // side's /write_b64_chunk. Both must be given together.
  const off = q.offset !== undefined ? parseInt(q.offset, 10) : NaN;
  const len = q.length !== undefined ? parseInt(q.length, 10) : NaN;
  if (Number.isFinite(off) || Number.isFinite(len)) {
    if (!(Number.isFinite(off) && Number.isFinite(len)) || off < 0 || len <= 0) {
      return fsFail(400, { error: "range read needs BOTH offset>=0 and length>0 (bytes)" });
    }
    if (off >= file.size) {
      return fsFail(416, { error: "offset " + off + " is past end of file (size " + file.size + ")", size: file.size });
    }
    if (len > MAX_BINARY) {
      return fsFail(413, { error: "length exceeds the " + MAX_BINARY + "-byte cap — request smaller ranges" });
    }
    const slice = new Uint8Array(await file.slice(off, Math.min(off + len, file.size)).arrayBuffer());
    await auditRow({ endpoint: "/read_b64", method: "GET", path: rg.relInRoot, status: 200, size: slice.length });
    return fsOk({ path: await echoPath(rg), offset: off, size: slice.length,
      total_size: file.size, b64: b64enc(slice),
      truncated: off + slice.length < file.size });
  }
  if (file.size > MAX_BINARY) {
    throw new OpFail(413, {
      error: "file too large: " + file.size + " > " + MAX_BINARY + " bytes",
      hint: "read it in ranges: /read_b64?path=…&offset=0&length=8000000, then offset=8000000, … (a Python helper can loop)",
    });
  }
  const bytes = new Uint8Array(await file.arrayBuffer());
  await auditRow({ endpoint: "/read_b64", method: "GET", path: rg.relInRoot, status: 200, size: bytes.length });
  return fsOk({ path: await echoPath(rg), size: bytes.length, b64: b64enc(bytes) });
}

async function epStat(q) {
  const rg = await resolveGuarded(formUnquote(q.path || ""));
  const name = rg.parts[rg.parts.length - 1];
  const w = await walkToParent(rg.rootRec, rg.parts, false);
  if (!w) return fsFail(404, { error: "not found: " + q.path });
  let file = null;
  try { file = await (await w.dir.getFileHandle(w.fileName)).getFile(); }
  catch (e) { /* maybe dir */ }
  if (file) {
    const ext = extOf(name);
    const kind = (ext === ".png" || ext === ".jpg" || ext === ".jpeg" || ext === ".gif" ||
      ext === ".webp" || ext === ".bmp") ? "image"
      : ext === ".pdf" ? "pdf"
      : [".docx", ".xlsx", ".pptx", ".odt", ".ods", ".odp"].includes(ext) ? "zip"
      : [".doc", ".xls", ".ppt"].includes(ext) ? "legacy"
      : [".txt", ".md", ".csv", ".json", ".xml", ".yml", ".yaml", ".log", ".py", ".js", ".html", ".css"].includes(ext) ? "text"
      : "other";
    return fsOk({ path: q.path, size: file.size, mtime: Math.floor(file.lastModified / 1000), kind: kind, ext: ext || null });
  }
  // directory?
  try {
    await w.dir.getDirectoryHandle(w.fileName);
    await auditRow({ endpoint: "/stat", method: "GET", path: rg.relInRoot, status: 200 });
    return fsOk({ path: q.path, size: null, mtime: null, kind: "dir", ext: extOf(name) || null });
  } catch (e) {
    return fsFail(404, { error: "not found: " + q.path });
  }
}

async function epSearch(q) {
  const term = formUnquote(q.q || "");
  if (!term) return fsFail(400, { error: "missing q" });
  const roots = await enabledRoots();
  if (!roots.length) throw new OpFail(503, { error: "no shared folder configured — click the Open File Bridge toolbar icon and choose a folder" });
  const rootRec = roots[0];
  const pats = await allIgnorePatterns(rootRec);
  const max = Math.min(parseInt(q.max || "50", 10) || 50, 200);
  // app takes case=sensitive; the old ext took 1|true — accept all three
  const caseSensitive = ["1", "true", "sensitive"].includes(String(q.case || "").toLowerCase());
  // app parity: context lines per match (default 1, max 5)
  const ctx = Math.max(0, Math.min(parseInt(q.context || "1", 10) || 1, 5));
  // app parity: exclude is a comma-separated list, matched against the rel path
  const excl = String(q.exclude || "").split(",").map((s) => s.trim()).filter(Boolean);
  const glob = q.glob ? formUnquote(q.glob) : null;
  const needle = caseSensitive ? term : term.toLowerCase();
  const matches = [];
  let scanned = 0;
  const t0 = Date.now();
  async function rec(dir, prefixParts) {
    if (matches.length >= max || Date.now() - t0 > 15000) return;
    for await (const [name, h] of dir.entries()) {
      if (matches.length >= max) return;
      const relParts = prefixParts.concat(name);
      const rel = relParts.join("/");
      const isDir = h.kind === "directory";
      if (ignoreMatch(rel, isDir, pats)) continue;
      if (isDir) { await rec(h, relParts); continue; }
      if (excl.some((p) => fnmatchStar(rel, p))) continue;
      // app parity: glob matches the full rel path (* crosses /)
      if (glob && !fnmatchStar(rel, glob)) continue;
      const ext = extOf(name);
      if (!TEXT_EXTS.has(ext) && !KNOWN_BASENAMES.has(name.toLowerCase())) continue;
      if (sensitiveName(name)) continue;
      let file;
      try { file = await h.getFile(); } catch (e) { continue; }
      if (file.size > 2000000) continue;
      const text = await file.text();
      scanned++;
      const lines = text.split("\n");
      for (let i = 0; i < lines.length && matches.length < max; i++) {
        const hay = caseSensitive ? lines[i] : lines[i].toLowerCase();
        if (!hay.includes(needle)) continue;
        const lo = Math.max(0, i - ctx), hi = Math.min(lines.length, i + ctx + 1);
        const context = [];
        for (let j = lo; j < hi; j++) context.push((j + 1) + ": " + lines[j].slice(0, MAX_LINE_CHARS));
        matches.push({ path: rel, line: i + 1, context: context });
      }
    }
  }
  await rec(rootRec.handle, []);
  await auditRow({ endpoint: "/search", method: "GET", path: ".", status: 200, size: matches.length });
  // app response shape: query/scanned_files/matches[{path,line,context}]/truncated
  return fsOk({ query: term, scanned_files: scanned, matches: matches, truncated: matches.length >= max });
}

async function epTree(q) {
  const rg0 = formUnquote(q.path || ".");
  const roots = await enabledRoots();
  if (!roots.length) throw new OpFail(503, { error: "no shared folder configured — click the Open File Bridge toolbar icon and choose a file" });
  let rootRec = roots[0];
  let startParts = [];
  const rel = rg0;
  if (rel && rel !== "." && rel !== "/") {
    const seg0 = rel.split("/")[0];
    if (seg0 && ROOT_ID_RE.test(seg0) && roots.some((r) => r.id === seg0)) {
      rootRec = roots.find((r) => r.id === seg0);
      startParts = rel.slice(seg0.length).replace(/^\/+/, "").split("/").filter(Boolean);
    } else {
      startParts = rel.split("/").filter(Boolean);
    }
  }
  let startDir = rootRec.handle;
  for (const seg of startParts) {
    try { startDir = await startDir.getDirectoryHandle(seg); }
    catch (e) { return fsFail(404, { error: "not a directory: " + q.path }); }
  }
  const maxEntries = Math.min(parseInt(q.max_entries || "500", 10) || 500, 2000);
  const maxDepth = Math.min(parseInt(q.max_depth || "6", 10) || 6, 12);
  const pats = await allIgnorePatterns(rootRec);
  const rootName = startParts.length ? startParts[startParts.length - 1] : (rootRec.alias || rootRec.id);
  let truncated = false, count = 0;
  async function node(dir, name, depth, prefixParts) {
    const children = [];
    const flat = [];
    for await (const [nm, h] of dir.entries()) flat.push([nm, h]);
    flat.sort((a, b) => (a[0] < b[0] ? -1 : 1));
    for (const [nm, h] of flat) {
      if (count >= maxEntries) { truncated = true; break; }
      const relParts = prefixParts.concat(nm);
      const rel = relParts.join("/");
      const isDir = h.kind === "directory";
      if (ignoreMatch(rel, isDir, pats)) continue;
      if (isDir) {
        count++;
        if (depth + 1 > maxDepth) {
          children.push({ name: nm, type: "dir", size: 0, children: [], truncated: true });
        } else {
          children.push(await node(h, nm, depth + 1, relParts));
        }
      } else {
        count++;
        let size = null;
        try { size = (await h.getFile()).size; } catch (e) {}
        children.push({ name: nm, type: "file", size: size });
      }
    }
    return { name: name, type: "dir", size: 0, children: children };
  }
  const tree = await node(startDir, rootName, 0, startParts);
  await auditRow({ endpoint: "/directory_tree", method: "GET", path: startParts.join("/") || ".", status: 200, size: count });
  return fsOk(Object.assign(
    { tree: tree, entry_count: count, truncated: truncated },
    truncated ? { hint: "increase max_entries/max_depth for more" } : {}));
}

/* ---------------- /find (pilot item 16, 2026-10-23) ----------------
 * Filename search — /search only covers CONTENT, so "where is
 * Nordvik_Template.pptx?" forced a /directory_tree walk or blind path
 * guesses (the most common wasted call in the scripted run; a capped
 * /list once hid the file and the model reported it nonexistent).
 * Native walk (no engine), case- AND accent-insensitive, * and ?
 * wildcards (else substring / all-words), capped at `max` (default 200). */
async function epFind(q) {
  // unquoteComp: parseQueryString is deliberately raw — an encoded
  // name=%C3%A4renden must decode before folding (same as paths)
  const namePat = unquoteComp(String(q.name || q.q || "")).trim();
  if (!namePat) {
    return fsFail(400, { error: "find needs a name pattern: /find?name=nordvik*template",
      hint: "case- and accent-insensitive; * and ? wildcards; optional path= (start folder), type= (file|dir), max=" });
  }
  const max = Math.max(1, Math.min(parseInt(q.max || "200", 10) || 200, 1000));
  const wantType = String(q.type || "").toLowerCase();
  const startPath = String(q.path || "").trim();
  const roots = await enabledRoots();
  if (!roots.length) throw new OpFail(503, { error: "no shared folder configured — click the Open File Bridge toolbar icon and choose a folder" });
  const starts = [];
  if (startPath) {
    const rg = await resolveGuarded(unquoteComp(startPath), {});
    let d = rg.rootRec.handle;
    for (const seg of rg.parts) {
      try { d = await d.getDirectoryHandle(seg); }
      catch (e) { return fsFail(404, { error: "not a directory: " + startPath }); }
    }
    starts.push({ dir: d, prefix: rg.relInRoot, rootRec: rg.rootRec });
  } else {
    const ps = await permState(roots[0].handle, "read");
    if (ps !== "granted") throw new OpFail(403, {
      error: "permission needed: the browser requires the user to re-confirm access to '" +
        (roots[0].alias || roots[0].id) + "'",
      permission_needed: true, root_id: roots[0].id, mode: "read",
      hint: "tell the user: click the Open File Bridge toolbar icon and press Reconnect — the folder is NOT re-picked, permission is re-asked on the stored handle",
    });
    for (const r of roots) starts.push({ dir: r.handle, prefix: "", rootRec: r });
  }
  const pat = foldName(namePat);
  const pats = await allIgnorePatterns(starts[0].rootRec);
  const matches = [];
  let truncated = false, visited = 0;
  const MAX_VISIT = 20000, TIME_BUDGET_MS = 10000;
  const t0 = Date.now();
  async function rec(dir, prefixParts) {
    for await (const [nm, h] of dir.entries()) {
      if (matches.length >= max || truncated) return;
      if (Date.now() - t0 > TIME_BUDGET_MS) { truncated = true; return; }
      if (visited++ > MAX_VISIT) { truncated = true; return; }
      const relParts = prefixParts.concat(nm);
      const rel = relParts.join("/");
      const isDir = h.kind === "directory";
      if (ignoreMatch(rel, isDir, pats)) continue;
      if (nameMatches(foldName(nm), pat) && (!wantType || (wantType === "dir") === isDir)) {
        let size = null, mtime = null;
        if (!isDir) {
          try { const f = await h.getFile(); size = f.size; mtime = f.lastModified; }
          catch (e) {}
        }
        matches.push({ path: rel, type: isDir ? "dir" : "file", size: size, mtime: mtime });
      }
      if (isDir) await rec(h, relParts);
    }
  }
  for (const st of starts) await rec(st.dir, st.prefix ? st.prefix.split("/") : []);
  await auditRow({ endpoint: "/find", method: "GET", path: startPath || ".", status: 200, size: matches.length });
  const out = { matches: matches, truncated: truncated, searched: namePat };
  if (truncated) out.hint = "result cut at " + matches.length + " — narrow with path= or a more specific name=";
  return fsOk(out);
}

/** Parse png/jpeg/gif/webp/bmp headers — port of the app's /image_info
 * walker (src/file_bridge.py): width/height + JPEG EXIF orientation, no
 * decoding. Missing since the Stage-3 port (the call site 500'd with
 * "imageInfoFromHeader is not defined" in a real chat 2026-09-09).
 * Returns {format,width,height,megapixels[,exif_orientation,
 * effective_width,effective_height,note]} or null. */
function imageInfoFromHeader(head, size) {
  if (!head || head.length < 12) return null;
  function be(off, n) {
    let v = 0;
    for (let i = 0; i < n; i++) v = v * 256 + (head[off + i] || 0);
    return v;
  }
  function le16(off) { return (head[off] || 0) | ((head[off + 1] || 0) << 8); }
  function le32(off) {
    return (head[off] || 0) | ((head[off + 1] || 0) << 8) |
      ((head[off + 2] || 0) << 16) | ((head[off + 3] || 0) << 24);
  }
  function sig(s, off) {
    for (let i = 0; i < s.length; i++)
      if (head[off + i] !== (s.charCodeAt(i) & 0xff)) return false;
    return true;
  }
  let fmt = null, w = null, h = null, orientation = null;
  if (sig("\x89PNG\r\n\x1a\n", 0)) {
    fmt = "png";
    if (sig("IHDR", 12)) { w = be(16, 4); h = be(20, 4); }
  } else if (sig("GIF87a", 0) || sig("GIF89a", 0)) {
    fmt = "gif"; w = le16(6); h = le16(8);
  } else if (head[0] === 0x42 && head[1] === 0x4d) { // "BM"
    fmt = "bmp"; w = le32(18); h = le32(22); // signed i32 (top-down BMPs use negative h)
  } else if (sig("RIFF", 0) && sig("WEBP", 8)) {
    fmt = "webp";
    if (sig("VP8 ", 12) && head[23] === 0x9d && head[24] === 0x01 && head[25] === 0x2a) {
      w = le16(26) & 0x3fff; h = le16(28) & 0x3fff;
    } else if (sig("VP8L", 12)) {
      const b0 = head[21], b1 = head[22], b2 = head[23], b3 = head[24];
      w = 1 + (((b1 & 0x3f) << 8) | b0);
      h = 1 + (((b3 & 0x0f) << 10) | (b2 << 2) | ((b1 & 0xc0) >> 6));
    } else if (sig("VP8X", 12)) {
      w = 1 + (head[24] | (head[25] << 8) | (head[26] << 16));
      h = 1 + (head[27] | (head[28] << 8) | (head[29] << 16));
    }
  } else if (head[0] === 0xff && head[1] === 0xd8) {
    fmt = "jpeg";
    let off = 2;
    while (off + 4 < head.length) {
      if (head[off] !== 0xff) { off++; continue; }
      const marker = head[off + 1];
      if (marker === 0xd8 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) { off += 2; continue; }
      const seglen = be(off + 2, 2);
      if (marker >= 0xc0 && marker <= 0xcf && marker !== 0xc4 && marker !== 0xc8 && marker !== 0xcc) {
        h = be(off + 5, 2); w = be(off + 7, 2); break; // SOFn
      }
      if (marker === 0xe1 && sig("Exif\x00\x00", off + 4)) {
        const tiff = off + 10;
        const little = head[tiff] === 0x49 && head[tiff + 1] === 0x49; // "II"
        const rd16 = (o) => little ? le16(o) : be(o, 2);
        const rd32 = (o) => little ? le32(o) : be(o, 4);
        const cntAt = tiff + rd32(tiff + 4); // IFD0 offset
        const n = rd16(cntAt);
        for (let k = 0; k < n; k++) {
          const ent = cntAt + 2 + k * 12;
          if (rd16(ent) === 0x0112) { orientation = rd16(ent + 8); break; } // Orientation
        }
      }
      off += 2 + seglen;
    }
  }
  if (!fmt || w == null) return null;
  const out = { format: fmt, width: w, height: h,
    megapixels: Math.round((w * h / 1e6) * 100) / 100 };
  if (orientation) {
    out.exif_orientation = orientation;
    const swap = orientation >= 5 && orientation <= 8;
    out.effective_width = swap ? h : w;
    out.effective_height = swap ? w : h;
    out.note = "EXIF orientation present — effective dims swap w/h; viewers auto-rotate but raw decoders may not";
  }
  return out;
}

async function epImageInfo(q) {
  const rg = await resolveGuarded(unquoteComp(q.path || ""));
  const file = await getFileFor(rg.rootRec, rg.parts);
  // 64 KB like the app — the JPEG marker/EXIF walk can run past 128 bytes
  const bytes = new Uint8Array(await file.slice(0, 65536).arrayBuffer());
  const info = imageInfoFromHeader(bytes, file.size);
  if (!info) {
    return fsFail(415, { error: "unsupported image format", hint: "supported: png/jpeg/gif/webp/bmp" });
  }
  await auditRow({ endpoint: "/image_info", method: "GET", path: rg.relInRoot, status: 200 });
  return fsOk(Object.assign({ path: q.path, size: file.size }, info));
}

async function epImageB64(q) {
  const rg = await resolveGuarded(formUnquote(q.path || ""));
  const file = await getFileFor(rg.rootRec, rg.parts);
  if (file.size > MAX_BINARY) {
    return fsFail(413, { error: "file too large: " + file.size + " > " + MAX_BINARY + " bytes" });
  }
  const clampParam = (v, lo, hi, dflt) => {
    const n = Math.floor(Number(v));
    return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : dflt;
  };
  // Default byte cap 4 MB = app parity (auto-downscale when over). The
  // extension additionally caps the long edge at 2000 px (EXIF-aware) —
  // good for chat display; pass max_bytes lower for smaller echoes.
  const maxBytes = clampParam(q.max_bytes, 10000, MAX_BINARY, 4000000);
  const maxEdge = clampParam(q.max_edge, 0, 8192, 2000);  // 0 disables the edge cap
  // 3.5.0 (pilot ask): format=png re-encodes so the b64 line can use the
  // host's data:image/png stdout upload (PNG-only feature)
  const forceMime = String(q.format || "").toLowerCase() === "png"
    ? "image/png" : null;
  const r = await fsImageToDataUrl(file, { maxBytes, maxEdge, forceMime });
  if (!r.ok) {
    return fsFail(413, {
      error: "image is " + file.size + " bytes; could not shrink under the "
           + maxBytes + "-byte cap",
      hint: "pass a larger max_bytes (≤ 8 MB) or max_edge=0 (no resize); "
          + "use /read_b64 for ORIGINAL bytes",
    });
  }
  await auditRow({ endpoint: "/image_b64", method: "GET", path: rg.relInRoot, status: 200, size: r.bytes });
  return fsOk({
    path: q.path, mime: r.mime, width: r.width, height: r.height,
    bytes: r.bytes, shrunk: r.shrunk,
    ...(r.shrunk ? { orig_bytes: r.origBytes, orig_width: r.origWidth, orig_height: r.origHeight } : {}),
    b64: r.b64, data_url: "data:" + r.mime + ";base64," + r.b64,
  });
}
